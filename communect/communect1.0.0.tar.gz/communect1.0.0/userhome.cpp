#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "userhome.h"
#include "ui_userhome.h"
#include "ui_messages.h"
#include "messages.h"

UserHome::UserHome(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserHome)
{
   // aa = g;
    ui->setupUi(this);

    //hide rates frame first
}

UserHome::~UserHome()
{
    delete ui;
}

void UserHome::on_pushButton_3_clicked()
{
   this->show();
   Messages *amessages = new Messages();
   amessages->setWindowFlags(Qt::Widget);

}
